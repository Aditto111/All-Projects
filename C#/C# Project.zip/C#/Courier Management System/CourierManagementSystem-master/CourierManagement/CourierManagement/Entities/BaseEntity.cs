﻿using System;

namespace CourierManagement
{
    class BaseEntity
    {
        public int Id { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}

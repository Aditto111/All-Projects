﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourierManagement.Entities
{
    class Price
    {
        public Price()
        {

        }
        
        public static float set_Price(string recive_branch,string send_branch)
        {
            return 100;
        }
    }
}

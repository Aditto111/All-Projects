#include <windows.h>  // for MS Windows
#include <GL/glut.h>  // GLUT, include glu.h and gl.h

void circle()
{

    glPushMatrix();
    glColor3f(1.000,0.000,0.000);
    glScalef(2.00,2.00,0.00);
    glutSolidSphere(15.5,100,10);

    glPopMatrix();
    glEnd();
}

void display() {

    glClearColor(0.000,0.502,0.000,0);
    glOrtho(-50.0,50.0,-50.0,50.0,-1.0,1.0);



	glClear(GL_COLOR_BUFFER_BIT);
	glPushMatrix();
	circle();
	glPopMatrix();
	glutSwapBuffers();
	glFlush();








	glFlush();  // Render now
}

int main(int argc, char** argv) {

	glutInit(&argc, argv);                 // Initialize GLUT
	glutCreateWindow("First L"); // Create a window with the given title
	glutInitWindowSize(320, 320);   // Set the window's initial width & height
	glutDisplayFunc(display); // Register display callback handler for window re-paint
	glutMainLoop();
	         // Enter the event-processing loop
	return 0;
}
